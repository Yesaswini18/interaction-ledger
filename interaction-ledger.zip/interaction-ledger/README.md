# Interaction Ledger & Reporting Pipeline

Ingests messy multi-channel interaction exports (voice, chat, SMS, WhatsApp, email) into an
append-only SQLite ledger, then produces **exact** per-day, per-channel metrics. Pure stdlib + pytest.

```
python scripts/generate_messy_data.py --out sample_data      # messy data + independent ground truth
python -m ledger ingest sample_data/*.csv sample_data/*.jsonl --db ledger.db
python -m ledger report --db ledger.db --tz Asia/Kolkata --out out/
python -m ledger state-hash --db ledger.db
python -m pytest -q                                           # 49 tests
```

## Architecture

```
files (.csv/.jsonl) -> normalise -> events (append-only ledger) -> interactions (VIEW) -> report
                          |                  |  \-> conflicts
                          \-> rejects        \-> source_files (provenance, counts)
```

| Table / view | Role |
|---|---|
| `source_files` | One row per ingested file, keyed by SHA-256 of its bytes |
| `events` | Source of truth. One row per distinct business event. Never updated except NULL-filling |
| `conflicts` | Same `event_id`, different content. First write wins, disagreement is recorded |
| `rejects` | Every unparseable row, with reason and raw text. Nothing is silently dropped |
| `interactions` | **View** rolled up from events. Cannot drift out of sync with the ledger |

## Idempotency (three layers)

1. **File level**: SHA-256 of bytes. Re-running, or a renamed copy, is skipped.
2. **Row level**: `event_key` = `id:<event_id>` if the source gave one, otherwise `h:<sha256 of normalised
   (interaction, type, UTC time, channel, amount)>`. Hashing happens *after* normalisation, so the same
   event re-exported with a different date format, phone format or currency string is still a duplicate.
3. **Atomic per file**: one transaction per file; a crash mid-file leaves no trace and the rerun is clean.

Because `interactions` is a view and reports are recomputed from events, reruns and out-of-order or
late-arriving data cannot double count. A test verifies identical state hashes for forward vs reverse file order.

## Exactness

- Money is **integer paise** end to end. Amounts are parsed with `Decimal`, never `float`.
  Values with sub-paisa precision are rejected, not rounded. A schema `CHECK` enforces positive integer amounts.
- Rates are integer **basis points**, averages integer seconds, both **round-half-up using integer math only**.
  Raw numerators/denominators (`resolved`, `interactions`, `handle_sec_sum`, `handle_n`) are always emitted too.
- Every report carries reconciliation checks (collected = ledger payment sum, interactions = distinct ledger
  interactions). The `report` command exits non-zero if any fails.

## Normalisation rules (decisions you may want to change)

| Topic | Rule |
|---|---|
| Timestamps | ISO, offsets, `Z`, epoch s/ms, and **day-first** `DD/MM/YYYY`. Naive times are assumed `Asia/Kolkata` (`--tz`). Stored as UTC, second precision |
| Channels | Aliases map to `voice/chat/sms/whatsapp/email`; unknown values are rejected |
| Phones | `+91`, `0`, `91` prefixes and separators converge to E.164; other `+` numbers kept; invalid rejected |
| Money | INR only (`₹`, `Rs.`, `INR`, commas). `$`/`USD` etc. rejected as `unsupported_currency` |
| Day bucketing | Local date (report `--tz`) of the interaction's **start** event; payments belong to their interaction |
| Resolved | Interaction has a `claim_resolved` or `payment_collected` event |
| Handle time | `end - start`, only when both exist and end >= start; others counted in `interactions_without_valid_handle_time` |
| Headless | Events with no start event are reported separately (count and money), never assigned a guessed day |
| Customers | Keyed by normalised phone, else email. Reports expose only a *count* of cross-channel customers (no PII) |

## Testing approach

`generate_messy_data.py` builds a clean model, renders it into four deliberately dirty files (mixed formats,
in-file duplicates, an overlapping re-export with different headers, orphan payments, 10 kinds of bad rows,
2 conflicting events, shuffled row order) and computes ground truth **from the model, not the pipeline**.
Tests assert the pipeline's report equals that truth to the paisa, plus idempotency, atomicity,
order-insensitivity, timezone bucketing, rounding, and schema constraints.

## Known limits

- No identity resolution across keys (a customer's phone and email are different customers).
- Conflict policy is first-write-wins (files are processed in sorted order); conflicts are surfaced for a human.
- Duplicates fill missing `agent_id`/`customer_key` only; two *different* non-null values keep the first.
- Event type, field and channel vocabularies are in `ledger/normalize.py` and are the place to adapt to a real feed.
