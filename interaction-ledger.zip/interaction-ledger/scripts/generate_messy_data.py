#!/usr/bin/env python3
"""Generate deliberately messy interaction exports PLUS an independently computed ground truth.

The truth is derived from the clean model, never from the pipeline, so tests compare two
separate implementations.

  python scripts/generate_messy_data.py --out sample_data --seed 7 --n 400
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import random
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

IST = ZoneInfo("Asia/Kolkata")
UTC = timezone.utc
CHANNELS = ["voice", "chat", "sms", "whatsapp", "email"]
CHANNEL_VARIANTS = {
    "voice": ["voice", "Call", "PHONE"], "chat": ["chat", "WebChat"],
    "sms": ["SMS", "text", "sms"], "whatsapp": ["whatsapp", "WA", "WhatsApp"],
    "email": ["email", "E-mail", "mail"],
}
TYPE_VARIANTS = {
    "interaction_started": ["interaction_started", "started", "call_started"],
    "interaction_ended": ["interaction_ended", "ended", "hangup"],
    "payment_collected": ["payment_collected", "paid", "payment"],
    "claim_resolved": ["claim_resolved", "resolved"],
    "message": ["message", "msg"],
}


def build_model(rng: random.Random, n: int):
    base = datetime(2026, 10, 28, tzinfo=IST)
    phones = ["9" + f"{rng.randrange(10**9):09d}" for _ in range(60)]
    interactions = []
    for i in range(n):
        ch = rng.choice(CHANNELS)
        c = rng.randrange(60)
        start = (base + timedelta(seconds=rng.randrange(0, 10 * 86400))).astimezone(UTC)
        dur = rng.randrange(20, 2400)
        has_end = rng.random() < 0.9
        payments, claim = [], False
        if rng.random() < 0.45:
            r = rng.random()
            if r < 0.55:
                payments = [rng.randrange(10_000, 5_000_000) for _ in range(rng.choice([1, 1, 2]))]
            claim = r >= 0.45
        ident = ("email", f"customer{c}@Example.com") if ch == "email" else ("phone", phones[c])
        ev = [dict(type="interaction_started", ts=start)]
        if has_end:
            ev.append(dict(type="interaction_ended", ts=start + timedelta(seconds=dur)))
        for amt in payments:
            ev.append(dict(type="payment_collected", ts=start + timedelta(seconds=rng.randrange(1, dur)), amount=amt))
        if claim:
            ev.append(dict(type="claim_resolved", ts=start + timedelta(seconds=rng.randrange(1, dur))))
        for _ in range(rng.randrange(0, 4)):
            ev.append(dict(type="message", ts=start + timedelta(seconds=rng.randrange(1, dur))))
        interactions.append(dict(id=f"INT-{i:05d}", channel=ch, ident=ident, start=start,
                                 dur=dur if has_end else None, resolved=bool(payments or claim),
                                 collected=sum(payments), events=ev))
    return interactions


def fmt_phone(p10: str, rng):
    return rng.choice([f"+91 {p10[:5]} {p10[5:]}", f"0{p10}", f"{p10[:5]}-{p10[5:]}", f"91{p10}", f"+91{p10}"])


def fmt_amount(minor: int, rng, as_number_ok=False):
    r, p = divmod(minor, 100)
    plain, grouped = f"{r}.{p:02d}", f"{r:,}.{p:02d}"
    opts = [f"₹{grouped}", f"Rs. {plain}", plain, f"INR {grouped}"]
    if p % 10 == 0:
        opts.append(f"{r}.{p // 10}")
    if as_number_ok:
        opts.append(float(plain))
    return rng.choice(opts)


def fmt_ts_a(dt):
    return dt.astimezone(IST).strftime("%d/%m/%Y %H:%M:%S")


def fmt_ts_b(dt, rng):
    k = rng.randrange(4)
    if k == 0:
        return dt.strftime("%Y-%m-%dT%H:%M:%SZ")
    if k == 1:
        return dt.astimezone(IST).strftime("%Y-%m-%dT%H:%M:%S+05:30")
    if k == 2:
        return int(dt.timestamp())
    return int(dt.timestamp()) * 1000


def ident_fields(ident, rng, phone_key, email_key):
    kind, val = ident
    if kind == "email":
        return {phone_key: "", email_key: val.upper() if rng.random() < 0.3 else val}
    return {phone_key: fmt_phone(val, rng), email_key: ""}


def flat_events(model):
    for it in model:
        for k, e in enumerate(it["events"]):
            yield it, k, e


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="sample_data")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--n", type=int, default=400)
    a = ap.parse_args()
    rng = random.Random(a.seed)
    out = Path(a.out)
    out.mkdir(parents=True, exist_ok=True)

    model = build_model(rng, a.n)
    A_rows, B_rows, overlap_rows = [], [], []
    b_payment_evs = []

    def a_row(it, e):
        r = {"interaction_id": it["id"], "event_type": rng.choice(TYPE_VARIANTS[e["type"]]),
             "timestamp": fmt_ts_a(e["ts"]), "channel": rng.choice(CHANNEL_VARIANTS[it["channel"]]),
             "agent_id": f"AG{rng.randrange(1, 9)}",
             "amount": fmt_amount(e["amount"], rng) if "amount" in e else ""}
        r.update(ident_fields(it["ident"], rng, "phone", "email"))
        return r

    def b_row(it, k, e, with_channel_on_end=False):
        evid = "EVT-" + hashlib.sha256(f"{a.seed}|{it['id']}|{k}".encode()).hexdigest()[:12]
        r = {"event_id": evid, "interaction_id": it["id"], "type": rng.choice(TYPE_VARIANTS[e["type"]]),
             "ts": fmt_ts_b(e["ts"], rng), "agent": f"AG{rng.randrange(1, 9)}"}
        if e["type"] != "interaction_ended" or with_channel_on_end:
            r["channel"] = rng.choice(CHANNEL_VARIANTS[it["channel"]])
        if "amount" in e:
            r["amount"] = fmt_amount(e["amount"], rng, as_number_ok=True)
        kind, val = it["ident"]
        if kind == "email":
            r["customer_email"] = val
        else:
            r["msisdn"] = fmt_phone(val, rng)
        return r

    for it, k, e in flat_events(model):
        if rng.random() < 0.5:
            A_rows.append(("A", it, k, e, a_row(it, e)))
        else:
            row = b_row(it, k, e)
            B_rows.append(("B", it, k, e, row))
            if e["type"] == "payment_collected":
                b_payment_evs.append((it, k, e, row))

    # headless payments (no start event ever seen)
    headless_total = 0
    for j in range(3):
        amt = rng.randrange(10_000, 900_000)
        headless_total += amt
        B_rows.append(("B", None, None, None, {
            "event_id": f"EVT-ORPHAN-{j}", "interaction_id": f"ORPHAN-{j}", "type": "payment_collected",
            "ts": "2026-11-02T10:00:00Z", "amount": fmt_amount(amt, rng)}))
    amt = rng.randrange(10_000, 900_000)
    headless_total += amt
    A_rows.append(("A", None, None, None, {
        "interaction_id": "ORPHAN-A", "event_type": "payment", "timestamp": "03/11/2026 09:15:00",
        "channel": "voice", "agent_id": "AG1", "amount": fmt_amount(amt, rng), "phone": "98765 43210", "email": ""}))

    # re-export overlap: ~25% of events again, different shape (aliased headers, ISO timestamps)
    for src, it, k, e, row in A_rows + B_rows:
        if it is None or rng.random() > 0.25:
            continue
        if src == "A":
            overlap_rows.append({"conversation_id": it["id"], "type": rng.choice(TYPE_VARIANTS[e["type"]]),
                                 "timestamp": e["ts"].strftime("%Y-%m-%dT%H:%M:%SZ"),
                                 "medium": CHANNEL_VARIANTS[it["channel"]][0], "event_id": "",
                                 "mobile": it["ident"][1] if it["ident"][0] == "phone" else "",
                                 "customer_email": it["ident"][1] if it["ident"][0] == "email" else "",
                                 "value": f"{e['amount'] // 100}.{e['amount'] % 100:02d}" if "amount" in e else ""})
        else:
            overlap_rows.append({"conversation_id": it["id"], "type": row["type"],
                                 "timestamp": e["ts"].strftime("%Y-%m-%dT%H:%M:%SZ"),
                                 "medium": "" if e["type"] == "interaction_ended" else CHANNEL_VARIANTS[it["channel"]][0],
                                 "event_id": row["event_id"],
                                 "mobile": it["ident"][1] if it["ident"][0] == "phone" else "",
                                 "customer_email": it["ident"][1] if it["ident"][0] == "email" else "",
                                 "value": f"{e['amount'] // 100}.{e['amount'] % 100:02d}" if "amount" in e else ""})

    # in-file verbatim duplicates (~5%)
    A_plain = [r for _, _, _, _, r in A_rows]
    B_plain = [r for _, _, _, _, r in B_rows]
    A_plain += [dict(r) for r in rng.sample(A_plain, len(A_plain) // 20)]
    B_plain += [dict(r) for r in rng.sample(B_plain, len(B_plain) // 20)]

    # injected bad rows (each triggers exactly one reject reason)
    good = dict(interaction_id="BAD", event_type="interaction_started", timestamp="05/11/2026 10:00:00",
                channel="voice", agent_id="AG1", amount="", phone="9876543210", email="")
    bad_a = [
        ({**good, "interaction_id": ""}, "missing_interaction_id"),
        ({**good, "timestamp": "sometime yesterday"}, "bad_timestamp"),
        ({**good, "event_type": "payment", "amount": "-500.00"}, "negative_amount"),
        ({**good, "event_type": "payment", "amount": "$12.00"}, "unsupported_currency"),
        ({**good, "phone": "12345"}, "invalid_phone"),
        ({**good, "channel": "carrier pigeon"}, "unknown_channel"),
        ({**good, "event_type": "teleported"}, "unknown_event_type"),
        ({**good, "event_type": "payment", "amount": ""}, "payment_missing_amount"),
    ]
    expected_rejects = {}
    for row, reason in bad_a:
        A_plain.append(row)
        expected_rejects[reason] = expected_rejects.get(reason, 0) + 1
    rng.shuffle(A_plain)
    rng.shuffle(B_plain)

    cols_a = ["interaction_id", "event_type", "timestamp", "channel", "phone", "email", "agent_id", "amount"]
    with (out / "events_a.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols_a, lineterminator="\n")
        w.writeheader()
        w.writerows(A_plain)

    with (out / "events_b.jsonl").open("w", encoding="utf-8") as f:
        lines = [json.dumps(r, ensure_ascii=False) for r in B_plain]
        lines.insert(rng.randrange(len(lines)), "{this is not json")
        lines.insert(rng.randrange(len(lines)), json.dumps(
            {"event_id": "EVT-BADTS", "interaction_id": "BAD-TS", "type": "message", "ts": 99999999999999,
             "channel": "chat"}))
        f.write("\n".join(lines) + "\n")
    expected_rejects["invalid_json"] = 1
    expected_rejects["timestamp_out_of_range"] = 1

    rng.shuffle(overlap_rows)
    cols_o = ["conversation_id", "type", "timestamp", "medium", "event_id", "mobile", "customer_email", "value"]
    with (out / "events_overlap.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols_o, lineterminator="\n")
        w.writeheader()
        w.writerows(overlap_rows)

    # conflicts: same event_id, different amount (first write must win)
    assert len(b_payment_evs) >= 2
    with (out / "zz_conflicts.jsonl").open("w", encoding="utf-8") as f:
        for it, k, e, row in b_payment_evs[:2]:
            bad = dict(row)
            bad["amount"] = f"{(e['amount'] + 1) // 100}.{(e['amount'] + 1) % 100:02d}"
            f.write(json.dumps(bad, ensure_ascii=False) + "\n")

    # ---- ground truth, from the clean model only ----
    daily = {}
    cust_ch = {}
    no_end = 0
    for it in model:
        day = it["start"].astimezone(IST).date().isoformat()
        d = daily.setdefault((day, it["channel"]), dict(interactions=0, resolved=0, collected_minor=0,
                                                         handle_sec_sum=0, handle_n=0))
        d["interactions"] += 1
        d["resolved"] += int(it["resolved"])
        d["collected_minor"] += it["collected"]
        if it["dur"] is None:
            no_end += 1
        else:
            d["handle_sec_sum"] += it["dur"]
            d["handle_n"] += 1
        cust_ch.setdefault(it["ident"], set()).add(it["channel"])
    n_events = sum(len(it["events"]) for it in model) + 4
    truth = {
        "daily_channel": [dict(date=d, channel=c, **v) for (d, c), v in sorted(daily.items())],
        "headless_interactions": 4,
        "headless_collected_minor": headless_total,
        "total_payments_minor": sum(it["collected"] for it in model) + headless_total,
        "events_loaded": n_events,
        "expected_rejects": expected_rejects,
        "expected_conflicts": 2,
        "interactions_without_valid_handle_time": no_end,
        "cross_channel_customers": sum(1 for v in cust_ch.values() if len(v) > 1),
    }
    (out / "ground_truth.json").write_text(json.dumps(truth, indent=2, sort_keys=True) + "\n")
    print(f"wrote {out}/ (events_a.csv, events_b.jsonl, events_overlap.csv, zz_conflicts.jsonl, ground_truth.json)")


if __name__ == "__main__":
    main()
