"""Pure normalisation: raw messy value -> canonical value, or RejectError(reason)."""
from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from zoneinfo import ZoneInfo

DEFAULT_TZ = ZoneInfo("Asia/Kolkata")


class RejectError(ValueError):
    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


CHANNEL_ALIASES = {
    "voice": "voice", "call": "voice", "phone": "voice", "ivr": "voice",
    "chat": "chat", "webchat": "chat", "web chat": "chat", "web_chat": "chat",
    "sms": "sms", "text": "sms",
    "whatsapp": "whatsapp", "wa": "whatsapp", "whats app": "whatsapp",
    "email": "email", "e-mail": "email", "mail": "email",
}

EVENT_TYPE_ALIASES = {
    "interaction_started": "interaction_started", "started": "interaction_started",
    "start": "interaction_started", "call_started": "interaction_started",
    "session_start": "interaction_started",
    "interaction_ended": "interaction_ended", "ended": "interaction_ended",
    "end": "interaction_ended", "hangup": "interaction_ended",
    "call_ended": "interaction_ended", "session_end": "interaction_ended",
    "payment_collected": "payment_collected", "payment": "payment_collected",
    "paid": "payment_collected", "payment_received": "payment_collected",
    "claim_resolved": "claim_resolved", "resolved": "claim_resolved",
    "resolution": "claim_resolved",
    "message": "message", "msg": "message",
}

FIELD_ALIASES = {
    "event_id": ("event_id", "id", "eventid"),
    "interaction_id": ("interaction_id", "conversation_id", "session_id"),
    "event_type": ("event_type", "type", "event"),
    "ts": ("ts", "timestamp", "time", "event_time"),
    "channel": ("channel", "medium"),
    "phone": ("phone", "msisdn", "customer_phone", "mobile"),
    "email": ("email", "customer_email"),
    "agent_id": ("agent_id", "agent"),
    "amount": ("amount", "amount_inr", "value"),
}

DAYFIRST_FORMATS = (
    "%d/%m/%Y %H:%M:%S", "%d-%m-%Y %H:%M:%S",
    "%d/%m/%Y %H:%M", "%d-%m-%Y %H:%M",
    "%d %b %Y %H:%M:%S",
)

_EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
_CURRENCY_STRIP = re.compile(r"(₹|rs\.?|inr)", re.I)
_FOREIGN_CURRENCY = re.compile(r"[$€£]|usd|eur|gbp", re.I)


def _blank(v) -> bool:
    return v is None or (isinstance(v, str) and not v.strip())


def norm_channel(value) -> str | None:
    if _blank(value):
        return None
    key = str(value).strip().lower()
    if key not in CHANNEL_ALIASES:
        raise RejectError("unknown_channel")
    return CHANNEL_ALIASES[key]


def norm_event_type(value) -> str:
    if _blank(value):
        raise RejectError("missing_event_type")
    key = str(value).strip().lower().replace(" ", "_")
    if key not in EVENT_TYPE_ALIASES:
        raise RejectError("unknown_event_type")
    return EVENT_TYPE_ALIASES[key]


def _from_epoch(v: float) -> datetime:
    if v >= 1e12:  # milliseconds
        v /= 1000.0
    if v < 1e9:  # before 2001 -> almost certainly not an epoch
        raise RejectError("bad_timestamp")
    try:
        return datetime.fromtimestamp(v, tz=timezone.utc)
    except (OverflowError, OSError, ValueError):
        raise RejectError("timestamp_out_of_range")


def parse_ts(value, default_tz=DEFAULT_TZ) -> str:
    """-> canonical UTC string 'YYYY-MM-DDTHH:MM:SSZ' (seconds precision, truncated).

    Naive timestamps are interpreted in default_tz. Slash/dash dates are DAY-FIRST.
    """
    if _blank(value):
        raise RejectError("missing_timestamp")
    dt = None
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        dt = _from_epoch(float(value))
    else:
        s = str(value).strip()
        if re.fullmatch(r"\d+(\.\d+)?", s):
            dt = _from_epoch(float(s))
        else:
            try:
                dt = datetime.fromisoformat(s.replace("Z", "+00:00"))
            except ValueError:
                for fmt in DAYFIRST_FORMATS:
                    try:
                        dt = datetime.strptime(s, fmt)
                        break
                    except ValueError:
                        continue
            if dt is None:
                raise RejectError("bad_timestamp")
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=default_tz)
    utc = dt.astimezone(timezone.utc).replace(microsecond=0)
    if not (2000 <= utc.year <= 2100):
        raise RejectError("timestamp_out_of_range")
    return utc.strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_amount_minor(value) -> int | None:
    """-> integer paise (minor units). Never touches floats for arithmetic."""
    if value is None:
        return None
    if isinstance(value, bool):
        raise RejectError("bad_amount")
    s = str(value).strip()
    if not s:
        return None
    if _FOREIGN_CURRENCY.search(s):
        raise RejectError("unsupported_currency")
    s = _CURRENCY_STRIP.sub("", s).replace(",", "").replace(" ", "")
    try:
        d = Decimal(s)
    except InvalidOperation:
        raise RejectError("bad_amount")
    if not d.is_finite():
        raise RejectError("bad_amount")
    if d < 0:
        raise RejectError("negative_amount")
    minor = d * 100
    if minor != minor.to_integral_value():
        raise RejectError("sub_paisa_precision")
    return int(minor)


def norm_phone(value) -> str | None:
    if _blank(value):
        return None
    raw = str(value).strip()
    digits = re.sub(r"\D", "", raw)
    if raw.startswith("+"):
        if 8 <= len(digits) <= 15:
            return "+" + digits
        raise RejectError("invalid_phone")
    if len(digits) == 10 and digits[0] in "6789":
        return "+91" + digits
    if len(digits) == 11 and digits[0] == "0" and digits[1] in "6789":
        return "+91" + digits[1:]
    if len(digits) == 12 and digits.startswith("91") and digits[2] in "6789":
        return "+" + digits
    raise RejectError("invalid_phone")


def norm_email(value) -> str | None:
    if _blank(value):
        return None
    e = str(value).strip().lower()
    if not _EMAIL_RE.match(e):
        raise RejectError("invalid_email")
    return e


def _canon_keys(raw: dict) -> dict:
    return {
        re.sub(r"[\s\-]+", "_", str(k).strip().lower()): v
        for k, v in raw.items() if k is not None
    }


def _pick(row: dict, field: str):
    for name in FIELD_ALIASES[field]:
        v = row.get(name)
        if not _blank(v):
            return v
    return None


def content_hash(interaction_id, event_type, ts_utc, channel, amount_minor) -> str:
    payload = json.dumps([interaction_id, event_type, ts_utc, channel, amount_minor],
                         separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def normalize_row(raw: dict, default_tz=DEFAULT_TZ) -> dict:
    row = _canon_keys(raw)

    iid = _pick(row, "interaction_id")
    if iid is None:
        raise RejectError("missing_interaction_id")
    iid = str(iid).strip()

    event_type = norm_event_type(_pick(row, "event_type"))
    ts = parse_ts(_pick(row, "ts"), default_tz)
    channel = norm_channel(_pick(row, "channel"))
    if event_type == "interaction_started" and channel is None:
        raise RejectError("missing_channel")

    phone = norm_phone(_pick(row, "phone"))
    email = norm_email(_pick(row, "email"))
    customer_key = f"tel:{phone}" if phone else (f"mailto:{email}" if email else None)

    amount = parse_amount_minor(_pick(row, "amount"))
    if event_type == "payment_collected":
        if amount is None:
            raise RejectError("payment_missing_amount")
        if amount == 0:
            raise RejectError("payment_zero_amount")
    else:
        amount = None

    agent = _pick(row, "agent_id")
    agent = str(agent).strip() if agent is not None else None
    event_id = _pick(row, "event_id")
    event_id = str(event_id).strip() if event_id is not None else None

    chash = content_hash(iid, event_type, ts, channel, amount)
    return {
        "event_key": f"id:{event_id}" if event_id else f"h:{chash}",
        "event_id": event_id,
        "content_hash": chash,
        "interaction_id": iid,
        "event_type": event_type,
        "ts_utc": ts,
        "channel": channel,
        "customer_key": customer_key,
        "agent_id": agent,
        "amount_minor": amount,
    }
