"""Exact reporting: integer arithmetic only, deterministic output, built-in reconciliation checks."""
from __future__ import annotations

import csv
import json
import sqlite3
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo


def div_round_half_up(num: int, den: int) -> int:
    """Exact round-half-up for non-negative integers (no floats)."""
    return (2 * num + den) // (2 * den)


def rate_bps(num: int, den: int):
    return div_round_half_up(num * 10_000, den) if den else None


def money(minor: int) -> str:
    return f"{minor // 100}.{minor % 100:02d}"


def _parse(ts: str) -> datetime:
    return datetime.strptime(ts, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)


def _new():
    return {"interactions": 0, "resolved": 0, "collected_minor": 0, "handle_sec_sum": 0, "handle_n": 0}


def _finish(key: dict, a: dict) -> dict:
    out = dict(key)
    out.update(a)
    out["resolution_rate_bps"] = rate_bps(a["resolved"], a["interactions"])
    out["avg_handle_sec"] = div_round_half_up(a["handle_sec_sum"], a["handle_n"]) if a["handle_n"] else None
    return out


def build_report(conn: sqlite3.Connection, tz_name: str = "Asia/Kolkata") -> dict:
    """Metrics are attributed to the LOCAL date (tz_name) of the interaction's start event.
    Payments belong to their interaction, so revenue lands on the day the interaction started."""
    tz = ZoneInfo(tz_name)
    daily = defaultdict(_new)
    by_channel = defaultdict(_new)
    overall = _new()
    headless = {"interactions": 0, "collected_minor": 0}
    cust_channels = defaultdict(set)
    handle_missing = 0

    rows = conn.execute(
        "SELECT interaction_id, start_ts, end_ts, has_start, resolved, collected_minor, channel, customer_key"
        " FROM interactions ORDER BY interaction_id").fetchall()
    for iid, start_ts, end_ts, has_start, resolved, collected, channel, cust in rows:
        if not has_start:  # events exist but we never saw the start: report separately, never guess a day
            headless["interactions"] += 1
            headless["collected_minor"] += collected
            continue
        s = _parse(start_ts)
        ch = channel or "unknown"
        day = s.astimezone(tz).date().isoformat()
        sec = None
        if end_ts:
            e = _parse(end_ts)
            if e >= s:
                sec = int((e - s).total_seconds())
        if sec is None:
            handle_missing += 1
        for agg in (daily[(day, ch)], by_channel[ch], overall):
            agg["interactions"] += 1
            agg["resolved"] += int(resolved)
            agg["collected_minor"] += collected
            if sec is not None:
                agg["handle_sec_sum"] += sec
                agg["handle_n"] += 1
        if cust:
            cust_channels[cust].add(ch)

    ledger_payments = conn.execute(
        "SELECT COALESCE(SUM(amount_minor),0) FROM events WHERE event_type='payment_collected'").fetchone()[0]
    distinct_interactions = conn.execute("SELECT COUNT(DISTINCT interaction_id) FROM events").fetchone()[0]
    reject_reasons = dict(conn.execute(
        "SELECT reason, COUNT(*) FROM rejects GROUP BY reason ORDER BY reason").fetchall())
    dup = conn.execute("SELECT COALESCE(SUM(rows_duplicate),0) FROM source_files").fetchone()[0]
    conflicts = conn.execute("SELECT COUNT(*) FROM conflicts").fetchone()[0]
    events_total = conn.execute("SELECT COUNT(*) FROM events").fetchone()[0]

    report = {
        "timezone": tz_name,
        "daily_channel": [_finish({"date": d, "channel": c}, a) for (d, c), a in sorted(daily.items())],
        "by_channel": [_finish({"channel": c}, a) for c, a in sorted(by_channel.items())],
        "overall": _finish({}, overall),
        "data_quality": {
            "events_in_ledger": events_total,
            "duplicate_rows_ignored": dup,
            "conflicting_rows": conflicts,
            "rejected_rows": sum(reject_reasons.values()),
            "reject_reasons": reject_reasons,
            "headless_interactions": headless["interactions"],
            "headless_collected_minor": headless["collected_minor"],
            "interactions_without_valid_handle_time": handle_missing,
            "cross_channel_customers": sum(1 for v in cust_channels.values() if len(v) > 1),
        },
    }
    report["checks"] = {
        "collected_reconciles_to_ledger":
            overall["collected_minor"] + headless["collected_minor"] == ledger_payments,
        "interactions_reconcile_to_ledger":
            overall["interactions"] + headless["interactions"] == distinct_interactions,
        "resolved_not_above_interactions": overall["resolved"] <= overall["interactions"],
    }
    return report


def write_outputs(report: dict, out_dir) -> None:
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "report.json").write_text(json.dumps(report, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    cols = ["date", "channel", "interactions", "resolved", "resolution_rate_bps",
            "collected_minor", "handle_sec_sum", "handle_n", "avg_handle_sec"]
    with (out / "daily_channel.csv").open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols, lineterminator="\n")
        w.writeheader()
        for row in report["daily_channel"]:
            w.writerow({k: ("" if row[k] is None else row[k]) for k in cols})


def render_text(report: dict) -> str:
    def pct(bps):
        return "-" if bps is None else f"{bps // 100}.{bps % 100:02d}%"

    lines = [f"Report (dates in {report['timezone']})", ""]
    lines.append(f"{'date':<11}{'channel':<10}{'n':>5}{'resolved':>9}{'rate':>9}{'collected':>14}{'avg_s':>7}")
    for r in report["daily_channel"]:
        lines.append(f"{r['date']:<11}{r['channel']:<10}{r['interactions']:>5}{r['resolved']:>9}"
                     f"{pct(r['resolution_rate_bps']):>9}{money(r['collected_minor']):>14}"
                     f"{'-' if r['avg_handle_sec'] is None else r['avg_handle_sec']:>7}")
    o = report["overall"]
    lines += ["", f"TOTAL: {o['interactions']} interactions, {o['resolved']} resolved "
                  f"({pct(o['resolution_rate_bps'])}), collected {money(o['collected_minor'])}, "
                  f"avg handle {o['avg_handle_sec']}s"]
    lines += ["", "Data quality:"]
    for k, v in report["data_quality"].items():
        lines.append(f"  {k}: {money(v) if k.endswith('_minor') else v}")
    lines += ["", "Checks: " + ", ".join(f"{k}={'OK' if v else 'FAIL'}" for k, v in report["checks"].items())]
    return "\n".join(lines)
