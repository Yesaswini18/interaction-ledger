"""SQLite schema. The events table is the append-only source of truth; everything else is derived."""
from __future__ import annotations

import hashlib
import json
import sqlite3

SCHEMA = """
CREATE TABLE IF NOT EXISTS source_files (
    file_id        INTEGER PRIMARY KEY,
    path           TEXT NOT NULL,
    sha256         TEXT NOT NULL UNIQUE,      -- file-level idempotency
    rows_total     INTEGER NOT NULL DEFAULT 0,
    rows_loaded    INTEGER NOT NULL DEFAULT 0,
    rows_duplicate INTEGER NOT NULL DEFAULT 0,
    rows_conflict  INTEGER NOT NULL DEFAULT 0,
    rows_rejected  INTEGER NOT NULL DEFAULT 0,
    ingested_at    TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    event_key      TEXT PRIMARY KEY,          -- 'id:<event_id>' or 'h:<content_hash>' (row-level idempotency)
    event_id       TEXT,
    content_hash   TEXT NOT NULL,
    interaction_id TEXT NOT NULL,
    event_type     TEXT NOT NULL CHECK (event_type IN
                   ('interaction_started','interaction_ended','payment_collected','claim_resolved','message')),
    ts_utc         TEXT NOT NULL,
    channel        TEXT CHECK (channel IS NULL OR channel IN ('voice','chat','sms','whatsapp','email')),
    customer_key   TEXT,
    agent_id       TEXT,
    amount_minor   INTEGER CHECK (amount_minor IS NULL OR amount_minor > 0),  -- integer paise, never float
    first_file_id  INTEGER REFERENCES source_files(file_id),
    first_row_num  INTEGER,
    CHECK ((event_type = 'payment_collected') = (amount_minor IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS ix_events_interaction ON events(interaction_id);

-- Same event_id re-sent with different content: first write wins, the disagreement is recorded.
CREATE TABLE IF NOT EXISTS conflicts (
    event_key     TEXT NOT NULL,
    incoming_hash TEXT NOT NULL,
    existing_hash TEXT NOT NULL,
    file_id       INTEGER NOT NULL REFERENCES source_files(file_id),
    row_num       INTEGER NOT NULL,
    PRIMARY KEY (event_key, incoming_hash)
);

-- Nothing is silently dropped: every unparseable row lands here with a reason.
CREATE TABLE IF NOT EXISTS rejects (
    file_id INTEGER NOT NULL REFERENCES source_files(file_id),
    row_num INTEGER NOT NULL,
    reason  TEXT NOT NULL,
    raw     TEXT NOT NULL,
    PRIMARY KEY (file_id, row_num)
);

-- Derived, order-insensitive rollup of the ledger. Always consistent with events.
CREATE VIEW IF NOT EXISTS interactions AS
SELECT
    e.interaction_id AS interaction_id,
    MIN(CASE WHEN e.event_type = 'interaction_started' THEN e.ts_utc END) AS start_ts,
    MAX(CASE WHEN e.event_type = 'interaction_ended'   THEN e.ts_utc END) AS end_ts,
    MIN(e.ts_utc) AS first_ts,
    MAX(e.event_type = 'interaction_started') AS has_start,
    MAX(e.event_type IN ('claim_resolved','payment_collected')) AS resolved,
    COALESCE(SUM(CASE WHEN e.event_type = 'payment_collected' THEN e.amount_minor END), 0) AS collected_minor,
    (SELECT x.channel FROM events x
      WHERE x.interaction_id = e.interaction_id AND x.channel IS NOT NULL
      ORDER BY (x.event_type = 'interaction_started') DESC, x.ts_utc, x.event_key LIMIT 1) AS channel,
    (SELECT x.customer_key FROM events x
      WHERE x.interaction_id = e.interaction_id AND x.customer_key IS NOT NULL
      ORDER BY (x.event_type = 'interaction_started') DESC, x.ts_utc, x.event_key LIMIT 1) AS customer_key
FROM events e
GROUP BY e.interaction_id;
"""


def connect(path: str = ":memory:") -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.execute("PRAGMA foreign_keys = ON")
    if path != ":memory:":
        conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA)
    return conn


def state_hash(conn: sqlite3.Connection) -> str:
    """Hash of the ledger content (excludes provenance/timestamps). Equal hash == identical state."""
    h = hashlib.sha256()
    q = ("SELECT event_key, content_hash, interaction_id, event_type, ts_utc, channel, "
         "customer_key, agent_id, amount_minor FROM events ORDER BY event_key")
    for row in conn.execute(q):
        h.update(json.dumps(row, ensure_ascii=False).encode("utf-8"))
        h.update(b"\n")
    return h.hexdigest()
