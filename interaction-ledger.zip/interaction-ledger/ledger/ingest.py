"""Idempotent, atomic, per-file ingestion."""
from __future__ import annotations

import csv
import hashlib
import json
import sqlite3
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path

from .normalize import DEFAULT_TZ, RejectError, normalize_row


@dataclass
class IngestResult:
    file: str
    status: str  # 'ingested' | 'skipped'
    total: int = 0
    loaded: int = 0
    duplicate: int = 0
    conflict: int = 0
    rejected: int = 0


def iter_rows(path: Path):
    """Yield (row_num, raw_row_or_text, early_reject_reason_or_None)."""
    suffix = path.suffix.lower()
    if suffix == ".csv":
        with path.open(newline="", encoding="utf-8-sig", errors="replace") as f:
            for i, row in enumerate(csv.DictReader(f), 1):
                yield i, row, None
    elif suffix in (".jsonl", ".ndjson"):
        with path.open(encoding="utf-8", errors="replace") as f:
            for i, line in enumerate(f, 1):
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                except json.JSONDecodeError:
                    yield i, line, "invalid_json"
                    continue
                if not isinstance(obj, dict):
                    yield i, line, "invalid_json"
                    continue
                yield i, obj, None
    else:
        raise ValueError(f"unsupported file type: {path.name}")


def ingest_file(conn: sqlite3.Connection, path: Path, default_tz=DEFAULT_TZ) -> IngestResult:
    path = Path(path)
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    if conn.execute("SELECT 1 FROM source_files WHERE sha256 = ?", (sha,)).fetchone():
        return IngestResult(path.name, "skipped")

    res = IngestResult(path.name, "ingested")
    with conn:  # one transaction per file: all rows or nothing
        file_id = conn.execute(
            "INSERT INTO source_files(path, sha256, ingested_at) VALUES (?,?,?)",
            (str(path), sha, datetime.now(timezone.utc).isoformat()),
        ).lastrowid

        for row_num, raw, early in iter_rows(path):
            res.total += 1
            try:
                if early:
                    raise RejectError(early)
                ev = normalize_row(raw, default_tz)
            except RejectError as err:
                res.rejected += 1
                raw_txt = raw if isinstance(raw, str) else json.dumps(raw, ensure_ascii=False, default=str)
                conn.execute("INSERT INTO rejects VALUES (?,?,?,?)",
                             (file_id, row_num, err.reason, raw_txt[:2000]))
                continue

            cur = conn.execute(
                "INSERT OR IGNORE INTO events(event_key, event_id, content_hash, interaction_id, event_type,"
                " ts_utc, channel, customer_key, agent_id, amount_minor, first_file_id, first_row_num)"
                " VALUES (?,?,?,?,?,?,?,?,?,?,?,?)",
                (ev["event_key"], ev["event_id"], ev["content_hash"], ev["interaction_id"],
                 ev["event_type"], ev["ts_utc"], ev["channel"], ev["customer_key"],
                 ev["agent_id"], ev["amount_minor"], file_id, row_num),
            )
            if cur.rowcount == 1:
                res.loaded += 1
                continue
            (existing,) = conn.execute("SELECT content_hash FROM events WHERE event_key = ?",
                                       (ev["event_key"],)).fetchone()
            if existing == ev["content_hash"]:
                res.duplicate += 1
                # A duplicate may carry attributes the first copy lacked (agent, customer).
                # Fill NULLs only, so the result doesn't depend on which file arrived first.
                conn.execute(
                    "UPDATE events SET agent_id = COALESCE(agent_id, ?), customer_key = COALESCE(customer_key, ?)"
                    " WHERE event_key = ?", (ev["agent_id"], ev["customer_key"], ev["event_key"]))
            else:
                res.conflict += 1
                conn.execute("INSERT OR IGNORE INTO conflicts VALUES (?,?,?,?,?)",
                             (ev["event_key"], ev["content_hash"], existing, file_id, row_num))

        conn.execute(
            "UPDATE source_files SET rows_total=?, rows_loaded=?, rows_duplicate=?, rows_conflict=?,"
            " rows_rejected=? WHERE file_id=?",
            (res.total, res.loaded, res.duplicate, res.conflict, res.rejected, file_id),
        )
    return res


def ingest_paths(conn: sqlite3.Connection, paths, default_tz=DEFAULT_TZ) -> list[IngestResult]:
    """Deterministic order (sorted) so first-write-wins conflict handling is reproducible."""
    return [ingest_file(conn, Path(p), default_tz) for p in sorted(set(map(str, paths)))]
