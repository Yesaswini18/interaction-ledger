from __future__ import annotations

import argparse
import sys
from zoneinfo import ZoneInfo

from .db import connect, state_hash
from .ingest import ingest_paths
from .reports import build_report, render_text, write_outputs


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="ledger", description="Interaction ledger & reporting pipeline")
    sub = p.add_subparsers(dest="cmd", required=True)

    pi = sub.add_parser("ingest", help="ingest .csv/.jsonl files (safe to re-run)")
    pi.add_argument("files", nargs="+")
    pi.add_argument("--db", default="ledger.db")
    pi.add_argument("--tz", default="Asia/Kolkata", help="tz assumed for naive timestamps")

    pr = sub.add_parser("report", help="build exact metrics from the ledger")
    pr.add_argument("--db", default="ledger.db")
    pr.add_argument("--tz", default="Asia/Kolkata", help="tz used to bucket days")
    pr.add_argument("--out", default=None, help="directory for report.json + daily_channel.csv")

    ph = sub.add_parser("state-hash", help="print a hash of the ledger content")
    ph.add_argument("--db", default="ledger.db")

    a = p.parse_args(argv)
    conn = connect(a.db)

    if a.cmd == "ingest":
        for r in ingest_paths(conn, a.files, ZoneInfo(a.tz)):
            if r.status == "skipped":
                print(f"{r.file}: already ingested (skipped)")
            else:
                print(f"{r.file}: rows={r.total} loaded={r.loaded} duplicate={r.duplicate} "
                      f"conflict={r.conflict} rejected={r.rejected}")
    elif a.cmd == "report":
        rep = build_report(conn, a.tz)
        if a.out:
            write_outputs(rep, a.out)
        print(render_text(rep))
        return 0 if all(rep["checks"].values()) else 1
    elif a.cmd == "state-hash":
        print(state_hash(conn))
    return 0


if __name__ == "__main__":
    sys.exit(main())
