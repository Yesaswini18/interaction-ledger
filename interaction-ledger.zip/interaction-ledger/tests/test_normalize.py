import pytest

from ledger.normalize import (RejectError, norm_channel, norm_email, norm_phone, normalize_row,
                              parse_amount_minor, parse_ts)


@pytest.mark.parametrize("raw,expected", [
    ("₹1,200.50", 120050), ("Rs. 1200", 120000), ("INR 12,34,567.5", 123456750),
    ("1200", 120000), (1200.5, 120050), (0, 0), ("0.07", 7), ("", None), (None, None),
])
def test_amount_ok(raw, expected):
    assert parse_amount_minor(raw) == expected


@pytest.mark.parametrize("raw,reason", [
    ("-5", "negative_amount"), ("$10", "unsupported_currency"), ("abc", "bad_amount"),
    ("10.005", "sub_paisa_precision"), ("NaN", "bad_amount"), ("Infinity", "bad_amount"),
])
def test_amount_rejects(raw, reason):
    with pytest.raises(RejectError) as e:
        parse_amount_minor(raw)
    assert e.value.reason == reason


@pytest.mark.parametrize("raw,expected", [
    ("2026-11-12T14:51:00Z", "2026-11-12T14:51:00Z"),
    ("2026-11-12T20:21:00+05:30", "2026-11-12T14:51:00Z"),
    ("12/11/2026 20:21:00", "2026-11-12T14:51:00Z"),   # day-first, naive -> IST
    ("12-11-2026 20:21", "2026-11-12T14:51:00Z"),
    ("2026-11-12 20:21:00", "2026-11-12T14:51:00Z"),   # naive ISO -> IST
    (1794149460, "2026-11-08T14:51:00Z"),
    (1794149460000, "2026-11-08T14:51:00Z"),
    ("1794149460", "2026-11-08T14:51:00Z"),
])
def test_ts_ok(raw, expected):
    assert parse_ts(raw) == expected


@pytest.mark.parametrize("raw,reason", [
    (None, "missing_timestamp"), ("  ", "missing_timestamp"), ("yesterday", "bad_timestamp"),
    ("31/02/2026 10:00", "bad_timestamp"), (99999999999999, "timestamp_out_of_range"), (123, "bad_timestamp"),
])
def test_ts_rejects(raw, reason):
    with pytest.raises(RejectError) as e:
        parse_ts(raw)
    assert e.value.reason == reason


@pytest.mark.parametrize("raw", ["+91 98765 43210", "09876543210", "98765-43210", "919876543210", "+919876543210"])
def test_phone_variants_converge(raw):
    assert norm_phone(raw) == "+919876543210"


def test_phone_rejects_and_intl():
    assert norm_phone("+1 415 555 0100") == "+14155550100"
    for bad in ("12345", "5555555555"):
        with pytest.raises(RejectError):
            norm_phone(bad)


def test_channel_and_email():
    assert norm_channel("WhatsApp") == norm_channel("wa") == "whatsapp"
    assert norm_channel("") is None
    with pytest.raises(RejectError):
        norm_channel("fax")
    assert norm_email(" A@B.com ") == "a@b.com"


def test_same_event_different_shape_same_key():
    a = normalize_row({"interaction_id": "X1", "event_type": "payment", "timestamp": "12/11/2026 20:21:00",
                       "channel": "Call", "amount": "₹1,000.00"})
    b = normalize_row({"conversation_id": "X1", "type": "payment_collected", "ts": "2026-11-12T14:51:00Z",
                       "medium": "voice", "value": 1000})
    assert a["event_key"] == b["event_key"]


def test_payment_rules():
    base = {"interaction_id": "X", "type": "payment", "ts": "2026-11-12T14:51:00Z"}
    for amt, reason in ((None, "payment_missing_amount"), ("0", "payment_zero_amount")):
        with pytest.raises(RejectError) as e:
            normalize_row({**base, "amount": amt})
        assert e.value.reason == reason
    started = normalize_row({"interaction_id": "X", "type": "start", "ts": "2026-11-12T14:51:00Z",
                             "channel": "sms", "amount": "99"})
    assert started["amount_minor"] is None  # amounts only meaningful on payments
