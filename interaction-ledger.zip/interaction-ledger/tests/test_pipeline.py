import json
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

from ledger import ingest as ingest_mod
from ledger.db import connect, state_hash
from ledger.ingest import ingest_paths
from ledger.reports import build_report, div_round_half_up, money, rate_bps

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def data_dir(tmp_path_factory):
    d = tmp_path_factory.mktemp("data")
    subprocess.run([sys.executable, str(ROOT / "scripts/generate_messy_data.py"), "--out", str(d),
                    "--seed", "7", "--n", "400"], check=True, capture_output=True)
    return d


@pytest.fixture(scope="module")
def truth(data_dir):
    return json.loads((data_dir / "ground_truth.json").read_text())


def all_files(d):
    return sorted(p for p in d.iterdir() if p.suffix in (".csv", ".jsonl"))


@pytest.fixture()
def loaded(data_dir):
    conn = connect(":memory:")
    ingest_paths(conn, all_files(data_dir))
    return conn


def test_report_matches_independent_ground_truth(loaded, truth):
    rep = build_report(loaded)
    got = [{k: r[k] for k in ("date", "channel", "interactions", "resolved", "collected_minor",
                              "handle_sec_sum", "handle_n")} for r in rep["daily_channel"]]
    assert got == truth["daily_channel"]
    dq = rep["data_quality"]
    assert dq["headless_interactions"] == truth["headless_interactions"]
    assert dq["headless_collected_minor"] == truth["headless_collected_minor"]
    assert dq["events_in_ledger"] == truth["events_loaded"]
    assert dq["reject_reasons"] == truth["expected_rejects"]
    assert dq["conflicting_rows"] == truth["expected_conflicts"]
    assert dq["interactions_without_valid_handle_time"] == truth["interactions_without_valid_handle_time"]
    assert dq["cross_channel_customers"] == truth["cross_channel_customers"]
    assert all(rep["checks"].values())
    total = rep["overall"]["collected_minor"] + dq["headless_collected_minor"]
    assert total == truth["total_payments_minor"]


def test_duplicates_were_actually_exercised(loaded):
    assert loaded.execute("SELECT SUM(rows_duplicate) FROM source_files").fetchone()[0] > 50


def test_conflicts_first_write_wins(loaded, truth):
    # totals still match truth (asserted above) and both conflicts are recorded with provenance
    n = loaded.execute("SELECT COUNT(*) FROM conflicts WHERE existing_hash <> incoming_hash").fetchone()[0]
    assert n == 2


def test_rerun_is_a_noop(data_dir):
    conn = connect(":memory:")
    ingest_paths(conn, all_files(data_dir))
    h1, r1 = state_hash(conn), json.dumps(build_report(conn), sort_keys=True)
    again = ingest_paths(conn, all_files(data_dir))
    assert all(r.status == "skipped" for r in again)
    assert state_hash(conn) == h1
    assert json.dumps(build_report(conn), sort_keys=True) == r1


def test_renamed_copy_is_skipped(data_dir, tmp_path):
    conn = connect(":memory:")
    ingest_paths(conn, all_files(data_dir))
    h = state_hash(conn)
    copy = tmp_path / "renamed_export.csv"
    shutil.copy(data_dir / "events_a.csv", copy)
    assert ingest_paths(conn, [copy])[0].status == "skipped"
    assert state_hash(conn) == h


def test_file_order_does_not_matter(data_dir):
    files = [p for p in all_files(data_dir) if p.name != "zz_conflicts.jsonl"]
    c1, c2 = connect(":memory:"), connect(":memory:")
    for p in files:
        ingest_mod.ingest_file(c1, p)
    for p in reversed(files):
        ingest_mod.ingest_file(c2, p)
    assert state_hash(c1) == state_hash(c2)
    assert json.dumps(build_report(c1), sort_keys=True) == json.dumps(build_report(c2), sort_keys=True)


def test_failed_file_leaves_no_trace_then_recovers(data_dir, monkeypatch):
    conn = connect(":memory:")
    real, calls = ingest_mod.normalize_row, {"n": 0}

    def flaky(raw, tz=None):
        calls["n"] += 1
        if calls["n"] == 5:
            raise RuntimeError("boom")
        return real(raw) if tz is None else real(raw, tz)

    monkeypatch.setattr(ingest_mod, "normalize_row", flaky)
    with pytest.raises(RuntimeError):
        ingest_mod.ingest_file(conn, data_dir / "events_a.csv")
    assert conn.execute("SELECT COUNT(*) FROM events").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM source_files").fetchone()[0] == 0
    assert conn.execute("SELECT COUNT(*) FROM rejects").fetchone()[0] == 0

    monkeypatch.setattr(ingest_mod, "normalize_row", real)
    assert ingest_mod.ingest_file(conn, data_dir / "events_a.csv").status == "ingested"


def test_partial_overlap_export_only_adds_new_events(tmp_path):
    f1, f2 = tmp_path / "a.csv", tmp_path / "b.csv"
    hdr = "interaction_id,event_type,timestamp,channel,phone,amount\n"
    f1.write_text(hdr + "I1,started,12/11/2026 10:00:00,call,9876543210,\n"
                        "I1,payment,12/11/2026 10:05:00,call,9876543210,₹500.00\n")
    f2.write_text(hdr + "I1,payment,12/11/2026 10:05:00,Call,98765 43210,Rs 500\n"   # same payment, different shape
                        "I1,ended,12/11/2026 10:10:00,call,9876543210,\n")
    conn = connect(":memory:")
    ingest_paths(conn, [f1, f2])
    rep = build_report(conn)
    assert rep["overall"]["collected_minor"] == 50000  # not double counted
    assert rep["overall"]["avg_handle_sec"] == 600


def test_day_bucketing_uses_local_tz_not_utc(tmp_path):
    f = tmp_path / "x.csv"
    f.write_text("interaction_id,event_type,timestamp,channel\n"
                 "I1,started,2026-11-12T19:00:00Z,chat\n")  # 00:30 IST on the 13th
    conn = connect(":memory:")
    ingest_paths(conn, [f])
    assert build_report(conn, "Asia/Kolkata")["daily_channel"][0]["date"] == "2026-11-13"
    assert build_report(conn, "UTC")["daily_channel"][0]["date"] == "2026-11-12"


def test_exact_rounding_and_money():
    assert div_round_half_up(5, 2) == 3 and div_round_half_up(4, 2) == 2 and div_round_half_up(1, 3) == 0
    assert rate_bps(1, 3) == 3333 and rate_bps(2, 3) == 6667 and rate_bps(1, 8) == 1250 and rate_bps(0, 0) is None
    assert money(5) == "0.05" and money(123456) == "1234.56"


def test_schema_rejects_float_style_or_negative_amounts():
    import sqlite3
    conn = connect(":memory:")
    conn.execute("INSERT INTO source_files(path,sha256,ingested_at) VALUES('p','s','t')")
    with pytest.raises(sqlite3.IntegrityError):
        conn.execute("INSERT INTO events(event_key,content_hash,interaction_id,event_type,ts_utc,amount_minor)"
                     " VALUES('k','h','i','payment_collected','2026-01-01T00:00:00Z',-5)")
    with pytest.raises(sqlite3.IntegrityError):  # payment without amount
        conn.execute("INSERT INTO events(event_key,content_hash,interaction_id,event_type,ts_utc)"
                     " VALUES('k2','h','i','payment_collected','2026-01-01T00:00:00Z')")
